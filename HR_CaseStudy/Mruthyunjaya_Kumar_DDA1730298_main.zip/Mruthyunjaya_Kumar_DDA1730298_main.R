##############################################################
# HR ANALYTICS CASE STUDY - LOGISTIC REGRESSION ASSIGNMENT ###
##############################################################

# Group members 
# D Mruthyunjaya Kumar (Facilitator) 
# Dharmanandana Reddy Pothula
# Sridhar
# Deepak Kumar

################################################################
#Business Understanding
#Data Preparation & EDA
#Model Building 
#Model Evaluation
################################################################

### Business Understanding:

# Based on the employee information, the company has maintained database containing demographic and
# personal information by conducting  the survey related to employee job satisfaction, yearof exp
# and worklife balance, performance ratings etc., 

## Goal:

# Automate the process and predict whether employee would leave or not and find the factors affecting 
# the employee attrition. 

################################################################

# Load essential libraries
library(MASS)
library(car)
library(caret)
library(ggplot2)
library(cowplot)
library(ggthemes)
library(caTools)
library(e1071)
library(ROCR)
library(dplyr)
library(GGally)
library(prettyunits)
library(chron)
library(tidyr)

#####################################################################
#       I. EDA                                                      #
#####################################################################
###### DATA UNDERSTANDING, PREPARATION & DATA ANALYSIS ##############

# Load employee Survey data, general data, manager data, intime and outtime csv files
employee_data <- read.csv("employee_survey_data.csv",stringsAsFactors = F)
general_data <- read.csv("general_data.csv",stringsAsFactors = F)
manager_data <- read.csv("manager_survey_data.csv",stringsAsFactors = F)
in_time <- read.csv("in_time.csv",stringsAsFactors = F)
out_time <- read.csv("out_time.csv",stringsAsFactors = F)

# structure of employee dataframes
str(employee_data)    # 4410 obs of 4 variables 
str(general_data) # 4410 obs of 24 variables 
str(manager_data) # 4410 obs of 3 variables
str(in_time) # 4410 obs of 262 variables
str(out_time) # 4410 obs of 262 variables

# summary of employee dataframes
summary(employee_data)
summary(general_data)
summary(in_time)
summary(manager_data)
summary(out_time)

colnames(in_time)[1]<- "EmployeeID"
colnames(out_time)[1]<- "EmployeeID"

# check and confirm employee id is the key in all three files
sum(duplicated(general_data$EmployeeID))    # 4410
sum(duplicated(employee_data$EmployeeID))    # 4410
sum(duplicated(manager_data$EmployeeID))    # 4410
sum(duplicated(in_time$EmployeeID))    # 4410
sum(duplicated(out_time$EmployeeID))    # 4410

# check wheter in_time and out_time contains data for the all the dates
setdiff(names(in_time),names(out_time))

# check employee id is identical across all dataframes
setdiff(employee_data$EmployeeID,general_data$EmployeeID) 
setdiff(employee_data$EmployeeID,manager_data$EmployeeID) 
setdiff(employee_data$EmployeeID,in_time$EmployeeID) 
setdiff(employee_data$EmployeeID,out_time$EmployeeID) 

## Following code for time difference is resource intensive and it is taking approximately 4 to 5 mins
######Mapping time difference between in_time and out_time from time dataframes
timediffmap <- Map(difftime, out_time[,-1], in_time[,-1])
timedf <- data.frame(double(),stringsAsFactors=FALSE) #Creating time dataframe 
timedf <- rep(0.0, nrow(in_time)) #initiase the datafame with 0 value
#Calculate total working hours for each employee
for(r in 1: nrow(in_time)){
  for(c in 1:(ncol(in_time)-1)){
    if(!is.na(timediffmap[[c]][r]))
    {timedf[r]= timedf[r]+timediffmap[[c]][r]}
  }
}
employee_data<- cbind(employee_data,timedf) 

# separate the datatime column into 2 separate columns date and time
# remove date part and keep only time from the in_time and out_time file
for(i in 1 : ncol(in_time)){
  df <- data.frame(x = in_time[,i])
  df <- df %>% separate(x, c("date", "time"),sep=" ")
  df <- df[,-1]
  in_time[,i] <- df
}
for(j in 1:ncol(out_time)){
  df <- data.frame(x=out_time[,j])
  df <- df %>% separate(x,c("date","time"),sep=" ")
  df <- df[,-1]
  out_time[,j] <- df
}
# remove columns from in_time and out_time files which contains only NA values
# check the na difference count between in_time and out_time
in_time <- in_time[,colSums(is.na(in_time))!=nrow(in_time)]
out_time <- out_time[,colSums(is.na(out_time))!=nrow(out_time)]
naDifferenceCount <- (sum(is.na(in_time)) - sum(is.na(out_time)))
naDifferenceCount

# Merge employee,general and manager datasets into single master dataframe 
masterdf <- merge(employee_data,manager_data,by="EmployeeID")
masterdf <- merge(masterdf,general_data,by="EmployeeID")

# checking for blank "" values; there are none
sapply(masterdf, function(x) length(which(x == "")))

####### Missing values (NA's) handling
sapply(masterdf, function(x) sum(is.na(x))) # shows NA's in master data frame
# NA's can be removed in multiple ways like NA's replaced with zeros (or) 
# NA's can be replaced with average derived out of respective column (or)
# NA's can be replaced with most frequent ones(mode) (or)
# obseravations having NA's can be deleted. if we choose this, it might affect model performance
# so based on business understanding, we have decided to replace NA's with mode
# Set missing TotalWorkingYears values with YearsAtCompany value as this can be considered as total working years

masterdf$NumCompaniesWorked[which(is.na(masterdf$NumCompaniesWorked))] <- 0

VariableValFreq <- table(masterdf$EnvironmentSatisfaction)
FreqValueName <- names(VariableValFreq[VariableValFreq==max(VariableValFreq)])
masterdf$EnvironmentSatisfaction[which(is.na(masterdf$EnvironmentSatisfaction))]<- as.numeric(FreqValueName)

VariableValFreq <- table(masterdf$JobSatisfaction)
FreqValueName <- names(VariableValFreq[VariableValFreq==max(VariableValFreq)])
masterdf$JobSatisfaction[which(is.na(masterdf$JobSatisfaction))]<- as.numeric(FreqValueName)

VariableValFreq <- table(masterdf$WorkLifeBalance)
FreqValueName <- names(VariableValFreq[VariableValFreq==max(VariableValFreq)])
masterdf$WorkLifeBalance[which(is.na(masterdf$WorkLifeBalance))]<- as.numeric(FreqValueName)

masterdf$TotalWorkingYears[which(is.na(masterdf$TotalWorkingYears))]<- masterdf$YearsAtCompany[which(is.na(masterdf$TotalWorkingYears))]


##### convert continous independent variables values into numeric
masterdf$JobSatisfaction <- as.numeric(masterdf$JobSatisfaction)
masterdf$WorkLifeBalance <- as.numeric(masterdf$WorkLifeBalance)
masterdf$EnvironmentSatisfaction <- as.numeric(masterdf$EnvironmentSatisfaction)
masterdf$timedf <- as.numeric(masterdf$timedf)
masterdf$JobInvolvement <- as.numeric(masterdf$JobInvolvement)
masterdf$PerformanceRating <- as.numeric(masterdf$PerformanceRating)
masterdf$Age <- as.numeric(masterdf$Age)
masterdf$DistanceFromHome <- as.numeric(masterdf$DistanceFromHome)
masterdf$Education <- as.numeric(masterdf$Education)
masterdf$EmployeeCount <- as.numeric(masterdf$EmployeeCount)
masterdf$JobLevel <- as.numeric(masterdf$JobLevel)
masterdf$MonthlyIncome <- as.numeric(masterdf$MonthlyIncome)
masterdf$NumCompaniesWorked <- as.numeric(masterdf$NumCompaniesWorked)
masterdf$PercentSalaryHike <- as.numeric(masterdf$PercentSalaryHike)
masterdf$StandardHours <- as.numeric(masterdf$StandardHours)
masterdf$StockOptionLevel <- as.numeric(masterdf$StockOptionLevel)
masterdf$TotalWorkingYears <- as.numeric(masterdf$TotalWorkingYears)
masterdf$TrainingTimesLastYear <- as.numeric(masterdf$TrainingTimesLastYear)
masterdf$YearsAtCompany <- as.numeric(masterdf$YearsAtCompany)
masterdf$YearsSinceLastPromotion <- as.numeric(masterdf$YearsSinceLastPromotion)
masterdf$YearsWithCurrManager <- as.numeric(masterdf$YearsWithCurrManager)


##########Univariate Analysis for categorical features ##################
# Barcharts for categorical features with stacked employee information
bar_theme1<- theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5), 
                   legend.position="none")

plot_grid(ggplot(masterdf, aes(x=BusinessTravel,fill=Attrition))+ geom_bar(), 
          ggplot(masterdf, aes(x=Department,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(masterdf, aes(x=EducationField,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(masterdf, aes(x=Gender,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(masterdf, aes(x=JobRole,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(masterdf, aes(x=MaritalStatus,fill=Attrition))+ geom_bar()+bar_theme1,
          align = "h")   

plot_grid(ggplot(masterdf, aes(x=EnvironmentSatisfaction,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(masterdf, aes(x=JobSatisfaction,fill=Attrition))+ geom_bar()+bar_theme1,
          ggplot(masterdf, aes(x=WorkLifeBalance,fill=Attrition))+ geom_bar() +bar_theme1,
          ggplot(masterdf, aes(x=JobInvolvement,fill=Attrition))+ geom_bar() +bar_theme1,
          ggplot(masterdf, aes(x=PerformanceRating,fill=Attrition))+ geom_bar() +bar_theme1,
          align = "h")

#reveals strong contrast for employee with respect to Gender, research development and marital status

# Histogram and Boxplots for numeric variables 
box_theme<- theme(axis.line=element_blank(),axis.title=element_blank(), 
                  axis.ticks=element_blank(), axis.text=element_blank())

box_theme_y<- theme(axis.line.y=element_blank(),axis.title.y=element_blank(), 
                    axis.ticks.y=element_blank(), axis.text.y=element_blank(),
                    legend.position="none")

plot_grid(ggplot(masterdf, aes(DistanceFromHome))+ geom_histogram(binwidth = 10),
          ggplot(masterdf, aes(x="",y=DistanceFromHome))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)

plot_grid(ggplot(masterdf, aes(PercentSalaryHike))+ geom_histogram(binwidth = 10),
          ggplot(masterdf, aes(x="",y=PercentSalaryHike))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)
# this plot reveals less number of employees that is between 1000 and 2000 in percentage 20 to 25%
plot_grid(ggplot(masterdf, aes(TotalWorkingYears))+ geom_histogram(binwidth = 10),
          ggplot(masterdf, aes(x="",y=TotalWorkingYears))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) 
# this plot reveals toatl working years shows some outliers, this we can reconfirm with quantile function in %
plot_grid(ggplot(masterdf, aes(MonthlyIncome))+ geom_histogram(binwidth = 10),
          ggplot(masterdf, aes(x="",y=MonthlyIncome))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)

plot_grid(ggplot(masterdf, aes(NumCompaniesWorked))+ geom_histogram(binwidth = 10),
          ggplot(masterdf, aes(x="",y=NumCompaniesWorked))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)
#this plot reveals employees worked in more number of companies are less
plot_grid(ggplot(masterdf, aes(TrainingTimesLastYear))+ geom_histogram(binwidth = 20),
          ggplot(masterdf, aes(x="",y=TrainingTimesLastYear))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) 

plot_grid(ggplot(masterdf, aes(YearsAtCompany))+ geom_histogram(binwidth = 20),
          ggplot(masterdf, aes(x="",y=YearsAtCompany))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1)

plot_grid(ggplot(masterdf, aes(YearsSinceLastPromotion))+ geom_histogram(binwidth = 30),
          ggplot(masterdf, aes(x="",y=YearsSinceLastPromotion))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) 

plot_grid(ggplot(masterdf, aes(YearsWithCurrManager))+ geom_histogram(binwidth = 30),
          ggplot(masterdf, aes(x="",y=YearsWithCurrManager))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) 
#timedf plot reveals that less employees who worked more number of hours 
plot_grid(ggplot(masterdf, aes(timedf))+ geom_histogram(binwidth = 20),
          ggplot(masterdf, aes(x="",y=timedf))+ geom_boxplot(width=0.1)+coord_flip()+box_theme, 
          align = "v",ncol = 1) 

# we  see some outliers in total working years and YearsAtCompany 
# and no outliers in others numeric variables, reconfirm with quantile
# Boxplots of numeric variables relative to employee attrition
plot_grid(ggplot(masterdf, aes(x=Attrition,y=MonthlyIncome, fill=Attrition))+ geom_boxplot(width=0.2)+ 
            coord_flip() +theme(legend.position="none"),
          ggplot(masterdf, aes(x=Attrition,y=TotalWorkingYears, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(masterdf, aes(x=Attrition,y=YearsAtCompany, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(masterdf, aes(x=Attrition,y=NumCompaniesWorked, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(masterdf, aes(x=Attrition,y=PercentSalaryHike, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          ggplot(masterdf, aes(x=Attrition,y=DistanceFromHome, fill=Attrition))+ geom_boxplot(width=0.2)+
            coord_flip() + box_theme_y,
          align = "v",nrow = 1)



##### Outliers Check ####################
# check for outliers in all continuous independent variables, different outlier detection methods used
# based on business data, however following method is used to detect and remove outliers
Outlier_PercentSalaryHike <- boxplot(masterdf$PercentSalaryHike,plot = FALSE)$out
Outlier_PercentSalaryHike
quantile(masterdf$PercentSalaryHike,seq(0,1,.01),na.rm = T) # no jump, no need to handle outlier here

Outlier_StandardHours <- boxplot(masterdf$StandardHours,plot = FALSE)$out
Outlier_StandardHours
quantile(masterdf$StandardHours,seq(0,1,.01),na.rm = T) # no jump, no need to handle outlier here

Outlier_StockOptionLevel <- boxplot(masterdf$StockOptionLevel,plot = FALSE)$out
Outlier_StockOptionLevel  
which(masterdf$StockOptionLevel %in% Outlier_StockOptionLevel)
quantile(masterdf$StockOptionLevel,seq(0,1,.01),na.rm = T) # no jump, no need to handle outlier here

Outlier_EmployeeCount <- boxplot(masterdf$EmployeeCount,plot = FALSE)$out
Outlier_EmployeeCount
quantile(masterdf$EmployeeCount,seq(0,1,.01),na.rm = T) # no jump, no need to handle outlier here

Outlier_DistanceFromHome <- boxplot(masterdf$DistanceFromHome,plot = FALSE)$out
Outlier_DistanceFromHome
quantile(masterdf$DistanceFromHome,seq(0,1,.01),na.rm = T) # no jump, no need to handle outlier here

Outlier_MonthlyIncome <- boxplot(masterdf$MonthlyIncome,plot = FALSE)$out
Outlier_MonthlyIncome
quantile(masterdf$MonthlyIncome,seq(0,1,.01),na.rm = T) # no jump, no need to handle outlier here

Outlier_NumCompaniesWorked <- boxplot(masterdf$NumCompaniesWorked,plot = FALSE)$out
Outlier_NumCompaniesWorked
quantile(masterdf$NumCompaniesWorked,seq(0,1,.01),na.rm = T) # no jump, no need to handle outlier here

Outlier_TotalWorkingYears <- boxplot(masterdf$TotalWorkingYears,plot = FALSE)$out
Outlier_TotalWorkingYears #this contains outliers
quantile(masterdf$TotalWorkingYears,seq(0,1,.01),na.rm = T) # we see sudden jump from 99% to 100% i.e., 35 to 40
masterdf$TotalWorkingYears[which(masterdf$TotalWorkingYears > 35)] <- 35 # removing outlier and setting to 35

Outlier_TrainingTimesLastYear <- boxplot(masterdf$TrainingTimesLastYear,plot = FALSE)$out
Outlier_TrainingTimesLastYear
quantile(masterdf$TrainingTimesLastYear,seq(0,1,.01),na.rm = T) # no outliers

Outlier_YearsAtCompany <- boxplot(masterdf$YearsAtCompany,plot = FALSE)$out
Outlier_YearsAtCompany
quantile(masterdf$YearsAtCompany,seq(0,1,.01),na.rm = T) # we see sudden jump from 98% to 100% i.e., 24 to 31
masterdf$YearsAtCompany[which(masterdf$YearsAtCompany > 24)] <- 24 # removing outlier and setting to 24

Outlier_YearsSinceLastPromotion <- boxplot(masterdf$YearsSinceLastPromotion,plot = FALSE)$out
Outlier_YearsSinceLastPromotion
quantile(masterdf$YearsSinceLastPromotion,seq(0,1,.01),na.rm = T) # we see sudden jump from 95% to 100% i.e., 9 to 15
masterdf$YearsSinceLastPromotion[which(masterdf$YearsSinceLastPromotion > 9)] <- 9 # removing outlier and setting to 9

Outlier_YearsWithCurrManager <- boxplot(masterdf$YearsWithCurrManager,plot = FALSE)$out
Outlier_YearsWithCurrManager
quantile(masterdf$YearsWithCurrManager,seq(0,1,.01),na.rm = T) # we see sudden jump from 99% to 100% i.e., 14 to 17
masterdf$YearsWithCurrManager[which(masterdf$YearsWithCurrManager > 14)] <- 14 # removing outlier and setting to 14

Outlier_timedf <- boxplot(masterdf$timedf,plot = FALSE)$out
Outlier_timedf
quantile(masterdf$timedf,seq(0,1,.01),na.rm = T) # we see sudden jump from 99% to 100% i.e., 2637.283 to 2723.378
masterdf$timedf[which(masterdf$timedf > 2637.283)] <- 2637.283 # removing outlier and setting to 2637.283

########## Correlation between numeric variables on employee dataset using plot
# years at company and total workiing years are showing strong correlation (0.62)
# total working years and age showing strong correlation (0.68)
# Years with current manager and Years at company showing very strong correlation (0.80)
ggpairs(masterdf[, c("MonthlyIncome", "NumCompaniesWorked","PercentSalaryHike","DistanceFromHome","TotalWorkingYears","TrainingTimesLastYear", "YearsAtCompany","timedf","YearsSinceLastPromotion", "YearsWithCurrManager")])

######### Continuous Variables standardisation ############################################
# Normalising continuous variables 
masterdf$Age<- scale(masterdf$Age) 
masterdf$PercentSalaryHike<- scale(masterdf$PercentSalaryHike) 
masterdf$TotalWorkingYears<- scale(masterdf$TotalWorkingYears) 
masterdf$YearsAtCompany<- scale(masterdf$YearsAtCompany) 
masterdf$timedf<- scale(masterdf$timedf) 
masterdf$YearsSinceLastPromotion<- scale(masterdf$YearsSinceLastPromotion) 
masterdf$YearsWithCurrManager<- scale(masterdf$YearsWithCurrManager) 
masterdf$TrainingTimesLastYear<- scale(masterdf$TrainingTimesLastYear)
masterdf$MonthlyIncome<- scale(masterdf$MonthlyIncome)
masterdf$DistanceFromHome<- scale(masterdf$DistanceFromHome)
masterdf$NumCompaniesWorked<- scale(masterdf$NumCompaniesWorked) 

# converting target variable masterdf from No/Yes character to factorwith levels 0/1 
masterdf$Attrition <- ifelse(masterdf$Attrition=="Yes",1,0)
masterdf$Over18 <- ifelse(masterdf$Over18=="Y",1,0)

# mapping master dataframe categorical numeric data to categories
masterdf$EnvironmentSatisfaction[masterdf$EnvironmentSatisfaction == 1] = "Low"
masterdf$EnvironmentSatisfaction[masterdf$EnvironmentSatisfaction == 2] = "Medium"
masterdf$EnvironmentSatisfaction[masterdf$EnvironmentSatisfaction == 3] = "High"
masterdf$EnvironmentSatisfaction[masterdf$EnvironmentSatisfaction == 4] = "Very High"

masterdf$JobSatisfaction[masterdf$JobSatisfaction == 1] = "Low"
masterdf$JobSatisfaction[masterdf$JobSatisfaction == 2] = "Medium"
masterdf$JobSatisfaction[masterdf$JobSatisfaction == 3] = "High"
masterdf$JobSatisfaction[masterdf$JobSatisfaction == 4] = "Very High"

masterdf$JobInvolvement[masterdf$JobInvolvement == 1] = "Low"
masterdf$JobInvolvement[masterdf$JobInvolvement == 2] = "Medium"
masterdf$JobInvolvement[masterdf$JobInvolvement == 3] = "High"
masterdf$JobInvolvement[masterdf$JobInvolvement == 4] = "Very High"

masterdf$WorkLifeBalance[masterdf$WorkLifeBalance == 1] = "Bad"
masterdf$WorkLifeBalance[masterdf$WorkLifeBalance == 2] = "Good"
masterdf$WorkLifeBalance[masterdf$WorkLifeBalance == 3] = "Better"
masterdf$WorkLifeBalance[masterdf$WorkLifeBalance == 4] = "Best"

masterdf$PerformanceRating[masterdf$PerformanceRating == 1] = "Low"
masterdf$PerformanceRating[masterdf$PerformanceRating == 2] = "Good"
masterdf$PerformanceRating[masterdf$PerformanceRating == 3] = "Excellent"
masterdf$PerformanceRating[masterdf$PerformanceRating == 4] = "Outstanding"

masterdf$Education[masterdf$Education == 1] = "Below College"
masterdf$Education[masterdf$Education == 2] = "College"
masterdf$Education[masterdf$Education == 3] = "Bachelor"
masterdf$Education[masterdf$Education == 4] = "Master"
masterdf$Education[masterdf$Education == 5] = "Doctor"

masterdf$JobLevel[masterdf$JobLevel == 1] = "JobLevel1"
masterdf$JobLevel[masterdf$JobLevel == 2] = "JobLevel2"
masterdf$JobLevel[masterdf$JobLevel == 3] = "JobLevel3"
masterdf$JobLevel[masterdf$JobLevel == 4] = "JobLevel4"
masterdf$JobLevel[masterdf$JobLevel == 5] = "JobLevel5"

masterdf$StockOptionLevel[masterdf$StockOptionLevel == 0] = "StockLevel0"
masterdf$StockOptionLevel[masterdf$StockOptionLevel == 1] = "StockLevel1"
masterdf$StockOptionLevel[masterdf$StockOptionLevel == 2] = "StockLevel2"
masterdf$StockOptionLevel[masterdf$StockOptionLevel == 3] = "StockLevel3"

Attrition <- sum(masterdf$Attrition)/nrow(masterdf)
Attrition #16.12% Attrition rate

##### Creation of dummy variables for categorical variables
masterCatVar<- masterdf[,c(2,3,4,6,7,10,11,13,14,16,17,18,19,25)] # creating a dataframe of categorical features
masterFact<- data.frame(sapply(masterCatVar, function(x) factor(x))) # converting categorical attributes to factor
dummies<- data.frame(sapply(masterFact, function(x) data.frame(model.matrix(~x-1,data =masterFact))[,-1]))# creating dummy variables for factor attributes
masterFinal<- cbind(masterdf[,-c(2,3,4,6,7,10,11,13,14,16,17,18,19,25)],dummies) # Final dataset

# generating correlation matrix on complete employee dataset  
# years at company and total workiing years are showing strong correlation (0.62)
# total working years and age showing strong correlation (0.68)
# Years with current manager and Years at company showing very strong correlation (0.80)
corr_df<-as.data.frame(cor(masterFinal)) 
print(corr_df)
View(corr_df)


##################################################################
#       II. MODEL BUILDING                                       #
##################################################################

##################################################################
# splitting the data between train and test
set.seed(100)
indices = sample.split(masterFinal$Attrition, SplitRatio = 0.7)
train = masterFinal[indices,]
test = masterFinal[!(indices),]

###################################################################
# Logistic Regression Model Building                              #
###################################################################

#Initial model
model_1 <- glm(Attrition~.,data=train,family = "binomial")
summary(model_1)


# Build model 2 after stepAIC operation, which has removed few insignificant variables
# Stepwise selection
model_2<- stepAIC(model_1, direction="both")
# Let us look at the summary of the model
summary(model_2)
# Removing multicollinearity through VIF check
vif(model_2)


# removing 'YearsAtCompany' variable as p-value > 0.05 (0.124926), re-build the model again
model_3 <- glm(Attrition ~ timedf + Age + DistanceFromHome + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                 WorkLifeBalance.xBetter + WorkLifeBalance.xGood + JobInvolvement.xLow + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.xBelow.College + Education.xCollege + EducationField.xOther + 
                 JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle + StockOptionLevel.xStockLevel1,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_3)
# Removing multicollinearity through VIF check
vif(model_3)


# removing 'EducationField.xOther' variable as p-value > 0.05 (0.123212), re-build the model again
model_4 <- glm(Attrition ~ timedf + Age + DistanceFromHome + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                 WorkLifeBalance.xBetter + WorkLifeBalance.xGood + JobInvolvement.xLow + 
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.xBelow.College + Education.xCollege +   
                 JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle + StockOptionLevel.xStockLevel1,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_4)
# Removing multicollinearity through VIF check
vif(model_4)


# removing 'JobInvolvement.xLow' variable as p-value > 0.05 (0.109894), re-build the model again
model_5 <- glm(Attrition ~ timedf + Age + DistanceFromHome + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                 WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.xBelow.College + Education.xCollege +   
                 JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle + StockOptionLevel.xStockLevel1,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_5)
# Removing multicollinearity through VIF check
vif(model_5)


# removing 'Education.xBelow.College' variable as p-value > 0.05 (0.106860), re-build the model again
model_6 <- glm(Attrition ~ timedf + Age + DistanceFromHome + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                 WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.xCollege +   
                 JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle + StockOptionLevel.xStockLevel1,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_6)
# Removing multicollinearity through VIF check
vif(model_6)


# removing 'DistanceFromHome' variable as p-value > 0.05 (0.089957), re-build the model again
model_7 <- glm(Attrition ~ timedf + Age + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                 WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.xCollege +   
                 JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle + StockOptionLevel.xStockLevel1,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_7)
# Removing multicollinearity through VIF check
vif(model_7)


# removing 'StockOptionLevel.xStockLevel1' variable as p-value > 0.05 (0.086037), re-build the model again
model_8 <- glm(Attrition ~ timedf + Age + MonthlyIncome + 
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                 WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.xCollege +   
                 JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_8)
# Removing multicollinearity through VIF check
vif(model_8)


# removing 'MonthlyIncome' variable as p-value > 0.05 (0.060301), re-build the model again
model_9 <- glm(Attrition ~ timedf + Age +  
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                 WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 Education.xCollege +   
                 JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_9)
# Removing multicollinearity through VIF check
vif(model_9)


# removing 'Education.xCollege' variable due to lower significance
# re-build the model again
model_10 <- glm(Attrition ~ timedf + Age +  
                 NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                 YearsSinceLastPromotion + YearsWithCurrManager + 
                 EnvironmentSatisfaction.xLow + EnvironmentSatisfaction.xVery.High + 
                 JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                 WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                 BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                 Department.xResearch...Development + Department.xSales + 
                 JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                 JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                 MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_10)
# Removing multicollinearity through VIF check
vif(model_10)


# removing 'EnvironmentSatisfaction.xVery.High' variable due to lower significance
# re-build the model again
model_11 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                  WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobLevel.xJobLevel2 + JobRole.xLaboratory.Technician + JobRole.xResearch.Director + 
                  JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_11)
# Removing multicollinearity through VIF check
vif(model_11)


# removing 'JobRole.xLaboratory.Technician' variable due to lower significance
# re-build the model again
model_12 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                  WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobLevel.xJobLevel2 + JobRole.xResearch.Director + 
                  JobRole.xResearch.Scientist + JobRole.xSales.Executive + 
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_12)
# Removing multicollinearity through VIF check
vif(model_12)


# removing 'JobRole.xResearch.Scientist' variable due to lower significance
# re-build the model again
model_13 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                  WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobLevel.xJobLevel2 + JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + 
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_13)
# Removing multicollinearity through VIF check
vif(model_13)


# removing 'JobLevel.xJobLevel2' variable due to lower significance
# re-build the model again
model_14 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                  WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobRole.xResearch.Director + 
                  JobRole.xSales.Executive + 
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_14)
# Removing multicollinearity through VIF check
vif(model_14)


# removing 'JobRole.xResearch.Director' variable due to lower significance
# re-build the model again
model_15 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                  WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  JobRole.xSales.Executive + 
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_15)
# Removing multicollinearity through VIF check
vif(model_15)


# removing 'JobRole.xSales.Executive' variable due to lower significance
# re-build the model again
model_16 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High + WorkLifeBalance.xBest + 
                  WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_16)
# Removing multicollinearity through VIF check
vif(model_16)


# removing 'WorkLifeBalance.xBest' variable due to lower significance
# re-build the model again
model_17 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High +  
                  WorkLifeBalance.xBetter + WorkLifeBalance.xGood +  
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_17)
# Removing multicollinearity through VIF check
vif(model_17)


# removing 'WorkLifeBalance.xGood' variable due to lower significance
# re-build the model again
model_18 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High +  
                  WorkLifeBalance.xBetter +   
                  BusinessTravel.xTravel_Frequently + BusinessTravel.xTravel_Rarely + 
                  Department.xResearch...Development + Department.xSales + 
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_18)
# Removing multicollinearity through VIF check
sort(vif(model_18))

# removed BusinessTravel.xTravel_Rarely as vif value is high 4.781828
model_19 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High +  
                  WorkLifeBalance.xBetter +   
                  BusinessTravel.xTravel_Frequently +  
                  Department.xResearch...Development + Department.xSales + 
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_19)
# Removing multicollinearity through VIF check
sort(vif(model_19))

# removed WorkLifeBalance.xBetter though p value is lower and but insignificant as it shows up with 2stars
model_20 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High +  
                  BusinessTravel.xTravel_Frequently +  
                  Department.xResearch...Development + Department.xSales + 
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_20)
# Removing multicollinearity through VIF check
sort(vif(model_20))

# removed Department.xResearch...Development as vif value is 3.766633 as it multi collinearity with Department.xSales
model_21 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High +  
                  BusinessTravel.xTravel_Frequently +  
                  Department.xSales +  
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_21)
# Removing multicollinearity through VIF check
sort(vif(model_21))

# removed Department.xSales as p value is higher
model_22 <- glm(Attrition ~ timedf + Age +  
                  NumCompaniesWorked + TotalWorkingYears + TrainingTimesLastYear + 
                  YearsSinceLastPromotion + YearsWithCurrManager + 
                  EnvironmentSatisfaction.xLow +  
                  JobSatisfaction.xLow + JobSatisfaction.xVery.High +  
                  BusinessTravel.xTravel_Frequently +  
                  MaritalStatus.xSingle,data=train,family = "binomial")
# Let us look at the summary of the model
summary(model_22)
# Removing multicollinearity through VIF check
sort(vif(model_22))

## As per model summary from 18th model, it shows all variables significant and 3 stars, so that
## we wanted to take this as final model and check the accuracy, specificity and sensitivity and k-value
## Final model-1 with 16 variables (variables optimized with lower p-values)
## we also proceeded to rebuilding models after 18th model, the reason is that some variables have high vif value
## and it is difficult to explain business insights with many variables, so optimized to 12 variables with model22
## and checked accuracy, specificity and sensitivity for model 22, its improved
## Final model-2 with 12 variables (variables further optimized with lower vif~2 and p-value)

###################################################################
###################################################################
#  III. MODEL EVALUATION FOR FINAL MODE-1                        ##
###################################################################
### This model performance: Accuracy - 0.7195767, Sensitivity-0.7089202, Specificity - 0.7216216 
### This model k-value - 0.4305418 (its good model,its above 40%)
###################################################################
# Final Model-1, With 16 significant variables, 18th model is final model
final_model<- model_18
### Test Data #####################################################

#predicted probabilities of Attrition 1 for test data

test_pred = predict(final_model, type = "response", newdata = test[,-4])
# Let's see the summary 
summary(test_pred)

test$prob <- test_pred
View(test)
# Let's use the probability cutoff of 50%.
test_pred_Attrition <- factor(ifelse(test_pred >= 0.50, "Yes", "No"))
test_actual_Attrition <- factor(ifelse(test$Attrition==1,"Yes","No"))

table(test_actual_Attrition,test_pred_Attrition)

# Let's use the probability cutoff of 40%.
test_pred_Attrition <- factor(ifelse(test_pred >= 0.40, "Yes", "No"))

test_conf <- confusionMatrix(test_pred_Attrition, test_actual_Attrition, positive = "Yes")

# Let's Choose the cutoff value. 
# Let's find out the optimal probalility cutoff 

perform_fn <- function(cutoff) 
{
  predicted_Attrition <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_Attrition, test_actual_Attrition, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# Summary of test probability
summary(test_pred)

s = seq(.01,.80,length=100)

OUT = matrix(0,100,3)

for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 

plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))

#the closest difference between sensitivity and specificity approximately 0.015, where both lines cut each other
cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.015)]
cutoff
# Let's choose a cutoff value of 0.1617 for final model
# cutoff value based on 0.015 is 0.1617 (approximately)
test_cutoff_Attrition <- factor(ifelse(test_pred >=0.1617, "Yes", "No"))

conf_final <- confusionMatrix(test_cutoff_Attrition, test_actual_Attrition, positive = "Yes")

acc <- conf_final$overall[1]
sens <- conf_final$byClass[1]
spec <- conf_final$byClass[2]

## This model performance: Accuracy - 0.7195767, Sensitivity-0.7089202, Specificity - 0.7216216 
acc
sens
spec

### KS -statistic - Test Data ######

test_cutoff_Attrition <- ifelse(test_cutoff_Attrition=="Yes",1,0)
test_actual_Attrition <- ifelse(test_actual_Attrition=="Yes",1,0)

#on testing  data
pred_object_test<- prediction(test_cutoff_Attrition, test_actual_Attrition)
performance_measures_test<- performance(pred_object_test, "tpr", "fpr")

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])
# K-value is 0.4305418 (good model,its above 40%)
max(ks_table_test)

# Lift & Gain Chart 
# plotting the lift chart

lift <- function(labels , predicted_prob,groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  return(gaintable)
}

Attrition_decile = lift(test_actual_Attrition, test_pred, groups = 10)
Attrition_decile

## As per model summary from 18th model, it shows all variables significant and 3 stars, so that
## we wanted to take this as final model and check the accuracy, specificity and sensitivity and k-value
## Final model-1 with 16 variables (variables optimized with lower p-values)
## we also proceeded to rebuilding models after 18th model, the reason is that some variables have high vif value
## and it is difficult to explain business insights with many variables, so optimized to 12 variables with model22
## and checked accuracy, specificity and sensitivity for model 22, its improved
## Final model-2 with 12 variables (variables further optimized with lower vif~2 and p-value)

###################################################################
###################################################################
#  III. MODEL EVALUATION FOR FINAL MODE-2                        ##
###################################################################
### This model performance: Accuracy - 0.7331822, Sensitivity-0.7370892, Specificity - 0.7324324 
### This model k-value - 0.4695216 (its pretty good model than previous one,its ~47%)
###################################################################

###################################################################
# Final Model-2, With 12 significant variables, 22nd model is final model
final_model<- model_22
### Test Data #####################################################

#predicted probabilities of Attrition 1 for test data

test_pred = predict(final_model, type = "response", newdata = test[,-4])
# Let's see the summary 
summary(test_pred)

test$prob <- test_pred
View(test)
# Let's use the probability cutoff of 50%.
test_pred_Attrition <- factor(ifelse(test_pred >= 0.50, "Yes", "No"))
test_actual_Attrition <- factor(ifelse(test$Attrition==1,"Yes","No"))

table(test_actual_Attrition,test_pred_Attrition)

# Let's use the probability cutoff of 40%.
test_pred_Attrition <- factor(ifelse(test_pred >= 0.40, "Yes", "No"))

test_conf <- confusionMatrix(test_pred_Attrition, test_actual_Attrition, positive = "Yes")

# Let's Choose the cutoff value. 
# Let's find out the optimal probalility cutoff 

perform_fn <- function(cutoff) 
{
  predicted_Attrition <- factor(ifelse(test_pred >= cutoff, "Yes", "No"))
  conf <- confusionMatrix(predicted_Attrition, test_actual_Attrition, positive = "Yes")
  acc <- conf$overall[1]
  sens <- conf$byClass[1]
  spec <- conf$byClass[2]
  out <- t(as.matrix(c(sens, spec, acc))) 
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  return(out)
}

# Summary of test probability
summary(test_pred)

s = seq(.01,.80,length=100)

OUT = matrix(0,100,3)

for(i in 1:100)
{
  OUT[i,] = perform_fn(s[i])
} 

plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)
axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)
lines(s,OUT[,2],col="darkgreen",lwd=2)
lines(s,OUT[,3],col=4,lwd=2)
box()
legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))

#the closest difference between sensitivity and specificity approximately 0.015, where both lines cut each other
cutoff <- s[which(abs(OUT[,1]-OUT[,2])<0.015)]
cutoff
# Let's choose a cutoff value of 0.1617 for final model
# cutoff value based on 0.015 is 0.1617 (approximately)
test_cutoff_Attrition <- factor(ifelse(test_pred >=0.1617, "Yes", "No"))

conf_final <- confusionMatrix(test_cutoff_Attrition, test_actual_Attrition, positive = "Yes")

acc <- conf_final$overall[1]
sens <- conf_final$byClass[1]
spec <- conf_final$byClass[2]
### This model performance: Accuracy - 0.7331822, Sensitivity-0.7370892, Specificity - 0.7324324 
acc
sens
spec

### KS -statistic - Test Data ######
test_cutoff_Attrition <- ifelse(test_cutoff_Attrition=="Yes",1,0)
test_actual_Attrition <- ifelse(test_actual_Attrition=="Yes",1,0)

#on testing  data
pred_object_test<- prediction(test_cutoff_Attrition, test_actual_Attrition)
performance_measures_test<- performance(pred_object_test, "tpr", "fpr")

ks_table_test <- attr(performance_measures_test, "y.values")[[1]] - 
  (attr(performance_measures_test, "x.values")[[1]])
### This model k-value - 0.4695216 (its pretty good model than previous one,its ~47%)
max(ks_table_test)

# Lift & Gain Chart 
# plotting the lift chart

lift <- function(labels , predicted_prob,groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(predicted_prob)) predicted_prob <- as.integer(as.character(predicted_prob))
  helper = data.frame(cbind(labels , predicted_prob))
  helper[,"bucket"] = ntile(-helper[,"predicted_prob"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totalresp=sum(., na.rm = TRUE))) %>%
    
    mutate(Cumresp = cumsum(totalresp),
           Gain=Cumresp/sum(totalresp)*100,
           Cumlift=Gain/(bucket*(100/groups))) 
  return(gaintable)
}

Attrition_decile = lift(test_actual_Attrition, test_pred, groups = 10)
Attrition_decile